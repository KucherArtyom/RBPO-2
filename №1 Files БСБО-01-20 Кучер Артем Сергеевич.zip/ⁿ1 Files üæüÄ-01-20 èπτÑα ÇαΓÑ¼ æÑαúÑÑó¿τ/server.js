(async function(){
const express = require('express');
const app = express();
const redis = require('redis')

const client  = redis.createClient({
	socket: {
		host: 'my-redis',
		port: 6379
	}
});

client.on('error', (err) => console.log('Redis Client Error', err));
await client.connect();

app.get('/', (req, res) => {
	res.sendFile(__dirname + '/index.html');
});

app.get('/getName', (req, res) => {
	const id = req.query.id;
	console.log('Got ID: ', id);
	(async function(){
		var name = await client.get(id);
		console.log('Found name:', name);
		if (!name) {
			name = 'Not found';
		}
		res.json({ name });
	})()
});

app.listen(3000, () => {
	console.log('Server running on http://localhost:3000');
});
})()
